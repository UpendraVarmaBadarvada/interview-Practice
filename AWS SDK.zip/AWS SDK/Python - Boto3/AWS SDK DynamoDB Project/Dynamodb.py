import boto3
from botocore.exceptions import ClientError

# Initialize DynamoDB client
dynamodb = boto3.resource('dynamodb', region_name='us-east-1')  # Change region as needed

# ---------------------------
# Check if Table Exists and Delete It
# ---------------------------
def check_and_delete_table():
    table_name = "Users"
    try:
        table = dynamodb.Table(table_name)
        table.load()  # Attempt to load table metadata
        print(f"Table '{table_name}' exists. Deleting it...")
        table.delete()
        table.wait_until_not_exists()
        print(f"Table '{table_name}' deleted successfully!")
    except ClientError as e:
        if e.response['Error']['Code'] == 'ResourceNotFoundException':
            print(f"Table '{table_name}' does not exist.")
        else:
            print(f"Error: {e.response['Error']['Message']}")

# ---------------------------
# Create Table
# ---------------------------
def create_table():
    try:
        check_and_delete_table()  # Ensure no existing table
        table_name = "Users"
        table = dynamodb.create_table(
            TableName=table_name,
            KeySchema=[{'AttributeName': 'user_id', 'KeyType': 'HASH'}],
            AttributeDefinitions=[{'AttributeName': 'user_id', 'AttributeType': 'S'}],
            ProvisionedThroughput={'ReadCapacityUnits': 5, 'WriteCapacityUnits': 5}
        )
        print("Creating table...")
        table.wait_until_exists()
        print(f"Table '{table_name}' created successfully!")
    except ClientError as e:
        print(f"Error: {e.response['Error']['Message']}")

# ---------------------------
# Insert Complex Item
# ---------------------------
def insert_complex_item():
    table_name = "Users"
    table = dynamodb.Table(table_name)
    try:
        user_id = input("Enter user_id (Partition Key): ")
        name = input("Enter name: ")
        email = input("Enter email: ")

        # Example: Collect address details
        address = {
            "street": input("Enter street: "),
            "city": input("Enter city: "),
            "state": input("Enter state: "),
            "zip": input("Enter zip code: ")
        }

        # Example: Collect preferences
        preferences = {
            "notifications": input("Enable notifications? (yes/no): ").lower() == "yes",
            "theme": input("Enter theme (light/dark): ")
        }

        # Example: Orders (List of Maps)
        orders = []
        while True:
            add_order = input("Add an order? (yes/no): ").lower() == "yes"
            if not add_order:
                break
            order_id = input("Enter order ID: ")
            items = []
            while True:
                add_item = input("Add an item to the order? (yes/no): ").lower() == "yes"
                if not add_item:
                    break
                product_id = input("Enter product ID: ")
                quantity = int(input("Enter quantity: "))
                price = float(input("Enter price: "))
                items.append({"product_id": product_id, "quantity": quantity, "price": price})
            total = sum(item["quantity"] * item["price"] for item in items)
            orders.append({"order_id": order_id, "items": items, "total": total})

        # Insert item into DynamoDB
        item = {
            "user_id": user_id,
            "name": name,
            "email": email,
            "address": address,
            "preferences": preferences,
            "orders": orders
        }
        table.put_item(Item=item)
        print(f"Complex item for user_id '{user_id}' inserted successfully!")
    except ClientError as e:
        print(f"Error: {e.response['Error']['Message']}")

# ---------------------------
# Update a Nested Attribute
# ---------------------------
def update_nested_attribute():
    table_name = "Users"
    table = dynamodb.Table(table_name)
    try:
        user_id = input("Enter user_id: ")
        attribute_path = input("Enter attribute path to update (e.g., address.city or preferences.theme): ")
        new_value = input("Enter the new value: ")
        update_expression = f"SET {attribute_path} = :val"
        table.update_item(
            Key={'user_id': user_id},
            UpdateExpression=update_expression,
            ExpressionAttributeValues={':val': new_value}
        )
        print(f"Nested attribute '{attribute_path}' updated successfully for user_id '{user_id}'!")
    except ClientError as e:
        print(f"Error: {e.response['Error']['Message']}")
        

# ---------------------------
# Get All Items
# ---------------------------
def get_all_items():
    table_name = "Users"
    table = dynamodb.Table(table_name)
    try:
        print("Retrieving all items...")
        response = table.scan()
        items = response.get('Items', [])
        if not items:
            print("No items found in the table.")
        else:
            print("All items:")
            for item in items:
                print(item)
    except ClientError as e:
        print(f"Error: {e.response['Error']['Message']}")

# ---------------------------
# Other CRUD Functions
# ---------------------------
def get_item():
    table_name = "Users"
    table = dynamodb.Table(table_name)
    try:
        user_id = input("Enter user_id to retrieve: ")
        response = table.get_item(Key={'user_id': user_id})
        if 'Item' in response:
            print("Retrieved Item:")
            print(response['Item'])
        else:
            print(f"Item with user_id '{user_id}' not found.")
    except ClientError as e:
        print(f"Error: {e.response['Error']['Message']}")

def update_order():
    table_name = "Users"
    table = dynamodb.Table(table_name)
    try:
        user_id = input("Enter user_id: ")
        order_id = input("Enter order_id to update: ")

        response = table.get_item(Key={'user_id': user_id})
        if 'Item' not in response:
            print(f"No item found with user_id '{user_id}'")
            return

        item = response['Item']
        orders = item.get('orders', [])
        for order in orders:
            if order['order_id'] == order_id:
                print(f"Current order: {order}")
                for item in order['items']:
                    print(f"Current item: {item}")
                    update_field = input("Enter field to update (product_id, quantity, price) or 'done' to finish: ")
                    if update_field == 'done':
                        break
                    if update_field in item:
                        new_value = input(f"Enter new value for {update_field}: ")
                        item[update_field] = int(new_value) if update_field == 'quantity' else float(new_value) if update_field == 'price' else new_value
                order['total'] = sum(i['quantity'] * i['price'] for i in order['items'])
                break
        else:
            print(f"No order found with order_id '{order_id}'")
            return

        table.update_item(
            Key={'user_id': user_id},
            UpdateExpression="SET orders = :orders",
            ExpressionAttributeValues={':orders': orders}
        )
        print(f"Order '{order_id}' updated successfully for user_id '{user_id}'!")
    except ClientError as e:
        print(f"Error: {e.response['Error']['Message']}")

def delete_item():
    table_name = "Users"
    table = dynamodb.Table(table_name)
    try:
        user_id = input("Enter user_id to delete: ")
        table.delete_item(Key={'user_id': user_id})
        print(f"Item with user_id '{user_id}' deleted successfully!")
    except ClientError as e:
        print(f"Error: {e.response['Error']['Message']}")

# ---------------------------
# Menu-Driven Interface
# ---------------------------
def menu():
    while True:
        print("\nDynamoDB Complex CRUD Menu")
        print("1. Create Table")
        print("2. Insert Complex Item")
        print("3. Retrieve Item")
        print("4. Update Nested Attribute")
        print("5. Update an Order")
        print("6. Delete Item")
        print("7. Get All Items")
        print("8. Exit")
        choice = input("Enter your choice: ")

        if choice == "1":
            create_table()
        elif choice == "2":
            insert_complex_item()
        elif choice == "3":
            get_item()
        elif choice == "4":
            update_nested_attribute()
        elif choice == "5":
            update_order()
        elif choice == "6":
            delete_item()
        elif choice == "7":
            get_all_items()
        elif choice == "8":
            print("Exiting...")
            break
        else:
            print("Invalid choice! Please try again.")

# ---------------------------
# Main Function
# ---------------------------
if __name__ == "__main__":
    menu()
