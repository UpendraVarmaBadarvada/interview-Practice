import json
import boto3
import os
import logging

# Initialize AWS clients and logger
s3_client = boto3.client('s3')
dynamodb = boto3.resource('dynamodb')
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Environment variables for DynamoDB table and key configuration
DYNAMO_TABLE = os.environ['DYNAMO_TABLE']
PARTITION_KEY = os.environ.get('PARTITION_KEY', 'id')  # Default to 'id' if not set
SORT_KEY = os.environ.get('SORT_KEY')  # Optional sort key

def lambda_handler(event, context):
    """
    AWS Lambda function to process S3 events, read JSON from files, and insert data into DynamoDB.
    """
    try:
        for record in event['Records']:
            bucket_name = record['s3']['bucket']['name']
            file_key = record['s3']['object']['key']
            logger.info(f"Processing file {file_key} from bucket {bucket_name}")

            # Read S3 file content
            file_obj = s3_client.get_object(Bucket=bucket_name, Key=file_key)
            file_content = file_obj['Body'].read().decode('utf-8')

            # Parse JSON and insert into DynamoDB
            table = dynamodb.Table(DYNAMO_TABLE)
            for line in file_content.splitlines():
                try:
                    item = json.loads(line)
                    
                    # Validate required keys
                    if PARTITION_KEY not in item or (SORT_KEY and SORT_KEY not in item):
                        logger.warning(f"Skipping line due to missing keys: {line}")
                        continue
                    
                    # Construct item for DynamoDB
                    dynamo_item = {
                        PARTITION_KEY: item[PARTITION_KEY],
                        **({SORT_KEY: item[SORT_KEY]} if SORT_KEY else {}),
                        **{k: v for k, v in item.items() if k not in {PARTITION_KEY, SORT_KEY}}
                    }

                    # Write to DynamoDB
                    table.put_item(Item=dynamo_item)
                except json.JSONDecodeError:
                    logger.error(f"Invalid JSON line: {line}")
                except Exception as e:
                    logger.error(f"Error inserting line into DynamoDB: {line} - {e}")

        return {'statusCode': 200, 'body': 'Processing completed successfully.'}

    except Exception as e:
        logger.error(f"Unhandled error: {e}")
        return {'statusCode': 500, 'body': str(e)}
