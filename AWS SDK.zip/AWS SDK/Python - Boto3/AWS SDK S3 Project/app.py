import boto3
import configparser
import os

def create_s3_client():
    # Initialize a parser
    config = configparser.ConfigParser()
    
    # Read the configuration file
    config.read('config.ini')
    
    # Extract credentials
    access_key = config['default']['aws_access_key_id']
    secret_key = config['default']['aws_secret_access_key']
    
    # Create an S3 client using the extracted credentials
    s3 = boto3.client(
        's3',
        aws_access_key_id=access_key,
        aws_secret_access_key=secret_key
    )
    return s3

def create_bucket(s3, bucket_name):
    try:
        s3.create_bucket(Bucket=bucket_name)
        print(f"Bucket {bucket_name} created successfully.")
    except Exception as e:
        print(f"Failed to create bucket: {e}")

def list_s3_buckets(s3):
    response = s3.list_buckets()
    buckets = [bucket['Name'] for bucket in response['Buckets']]
    if buckets:
        print("Bucket List:")
        for bucket in buckets:
            print(bucket)
    else:
        print("No buckets found.")

def delete_bucket(s3, bucket_name):
    try:
        s3.delete_bucket(Bucket=bucket_name)
        print(f"Bucket {bucket_name} deleted successfully.")
    except Exception as e:
        print(f"Failed to delete bucket: {e}")

def list_bucket_contents(s3, bucket_name):
    try:
        response = s3.list_objects_v2(Bucket=bucket_name)
        if 'Contents' in response:
            print(f"Contents of bucket {bucket_name}:")
            for obj in response['Contents']:
                print(obj['Key'])
        else:
            print(f"No contents found in {bucket_name}.")
    except Exception as e:
        print(f"Error: {e}")

def upload_files(s3, bucket_name, directory):
    try:
        for filename in os.listdir(directory):
            filepath = os.path.join(directory, filename)
            if os.path.isfile(filepath):
                s3.upload_file(filepath, bucket_name, filename)
                print(f"Uploaded {filename} to {bucket_name}.")
    except Exception as e:
        print(f"Failed to upload files: {e}")

def create_folder_in_bucket(s3, bucket_name, folder_name):
    try:
        # Creating a folder by uploading a zero-byte object with a '/' in the key
        folder_key = folder_name + '/'  # Adding trailing slash to indicate folder
        s3.put_object(Bucket=bucket_name, Key=folder_key)
        print(f"Folder '{folder_name}' created in bucket '{bucket_name}'.")
    except Exception as e:
        print(f"Failed to create folder: {e}")

def sync_buckets(s3, source_bucket, destination_bucket):
    try:
        # Syncing from source to destination
        command = f"aws s3 sync s3://{source_bucket} s3://{destination_bucket} --exact-timestamps"
        os.system(command)
        print(f"Sync completed from {source_bucket} to {destination_bucket}.")
    except Exception as e:
        print(f"Failed to sync buckets: {e}")

def delete_folder_contents(s3, bucket_name, folder_name):
    try:
        # List all objects in the folder and delete recursively
        response = s3.list_objects_v2(Bucket=bucket_name, Prefix=folder_name)
        if 'Contents' in response:
            for obj in response['Contents']:
                s3.delete_object(Bucket=bucket_name, Key=obj['Key'])
                print(f"Deleted {obj['Key']} from {bucket_name}.")
        else:
            print(f"No objects found in {folder_name} of bucket {bucket_name}.")
    except Exception as e:
        print(f"Failed to delete folder contents: {e}")

def main():
    s3 = create_s3_client()
    
    while True:
        print("\n1. Create a new S3 bucket")
        print("2. List all S3 buckets")
        print("3. Delete an S3 bucket")
        print("4. List contents of a specific S3 bucket")
        print("5. Upload files from a directory to a bucket")
        print("6. Exit")
        print("7. Create a folder in an existing S3 bucket")
        print("8. Sync content between two S3 buckets")
        print("9. Delete all contents of a folder in a bucket")
        choice = input("Enter your choice (1-9): ")

        if choice == '1':
            bucket_name = input("Enter the bucket name to create: ")
            create_bucket(s3, bucket_name)
        elif choice == '2':
            list_s3_buckets(s3)
        elif choice == '3':
            bucket_name = input("Enter the bucket name to delete: ")
            delete_bucket(s3, bucket_name)
        elif choice == '4':
            bucket_name = input("Enter the bucket name to list contents: ")
            list_bucket_contents(s3, bucket_name)
        elif choice == '5':
            bucket_name = input("Enter the bucket name to upload files to: ")
            directory = input("Enter the directory path to upload from: ")
            upload_files(s3, bucket_name, directory)
        elif choice == '7':
            bucket_name = input("Enter the bucket name where you want to create a folder: ")
            folder_name = input("Enter the folder name to create: ")
            create_folder_in_bucket(s3, bucket_name, folder_name)
        elif choice == '8':
            source_bucket = input("Enter the source S3 bucket name: ")
            destination_bucket = input("Enter the destination S3 bucket name: ")
            sync_buckets(s3, source_bucket, destination_bucket)
        elif choice == '9':
            bucket_name = input("Enter the bucket name: ")
            folder_name = input("Enter the folder name to delete contents: ")
            delete_folder_contents(s3, bucket_name, folder_name)
        elif choice == '6':
            print("Exiting program.")
            break
        else:
            print("Invalid choice. Please try again.")

if __name__ == "__main__":
    main()
