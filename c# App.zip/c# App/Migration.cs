﻿using System;
using System.Xml;
namespace MainApp.MigrationFunctions
{
	public class Migration
	{
        private static void UpdateVersion(XmlDocument xmlDoc, string newVersion, string xmlFilePath)
        {
            XmlNode childNode = xmlDoc.SelectSingleNode("//Child");
            if (childNode != null && childNode.Attributes["version"] != null)
            {
                childNode.Attributes["version"].Value = newVersion;
                xmlDoc.Save(xmlFilePath); // Save the updated XML file

                Console.WriteLine($"[LOG] Migration applied. Updated version to {newVersion} and saved to {xmlFilePath}");
            }
            else
            {
                Console.WriteLine("[ERROR] Version attribute not found in XML.");
            }
        }

        public void MigrateToV_2_0(XmlDocument xmlDoc, string moduleName, string xmlFilePath)
        {
            Console.WriteLine($"Processing {moduleName} with config {xmlFilePath} in MigrateToV_2_0...");
            UpdateVersion(xmlDoc, "2.0", xmlFilePath); // Save in the config file
        }

        public void MigrateToV_2_1(XmlDocument xmlDoc, string xmlFilePath)
        {
            UpdateVersion(xmlDoc, "2.1", xmlFilePath);
        }

        public void MigrateToV_2_2(XmlDocument xmlDoc, string xmlFilePath)
        {
            UpdateVersion(xmlDoc, "2.2", xmlFilePath);
        }

        public void MigrateToV_2_3(XmlDocument xmlDoc, string xmlFilePath)
        {
            UpdateVersion(xmlDoc, "2.3", xmlFilePath);
        }

        public void MigrateToV_2_4(XmlDocument xmlDoc, string xmlFilePath)
        {
            UpdateVersion(xmlDoc, "2.4", xmlFilePath);
        }

        public void MigrateToV_2_5(XmlDocument xmlDoc, string xmlFilePath)
        {
            UpdateVersion(xmlDoc, "2.5", xmlFilePath);
        }

        public void MigrateToV_2_6(XmlDocument xmlDoc, string xmlFilePath)
        {
            UpdateVersion(xmlDoc, "2.6", xmlFilePath);
        }

        public void MigrateToV_2_6HF3(XmlDocument xmlDoc, string xmlFilePath)
        {
            UpdateVersion(xmlDoc, "2.6.3", xmlFilePath);
        }

        public void MigrateToV_2_7(XmlDocument xmlDoc, string xmlFilePath)
        {
            UpdateVersion(xmlDoc, "2.7", xmlFilePath);
        }

        public void MigrateToV_2_8(XmlDocument xmlDoc, string xmlFilePath)
        {
            UpdateVersion(xmlDoc, "2.8", xmlFilePath);
        }

        public void MigrateToV_2_9(XmlDocument xmlDoc, string xmlFilePath)
        {
            UpdateVersion(xmlDoc, "2.9", xmlFilePath);
        }

        public void MigrateToV_2_10(XmlDocument xmlDoc, string xmlFilePath)
        {
            UpdateVersion(xmlDoc, "2.10", xmlFilePath);
        }

        public void MigrateToV_2_11(XmlDocument xmlDoc, string xmlFilePath)
        {
            UpdateVersion(xmlDoc, "2.11", xmlFilePath);
        }

        public void MigrateToV_2_12(XmlDocument xmlDoc, string xmlFilePath)
        {
            UpdateVersion(xmlDoc, "2.12", xmlFilePath);
        }

        public void MigrateToV_2_13(XmlDocument xmlDoc, string xmlFilePath)
        {
            UpdateVersion(xmlDoc, "2.13", xmlFilePath);
        }

        public void MigrateToV_2_13HF2(XmlDocument xmlDoc, string xmlFilePath)
        {
            UpdateVersion(xmlDoc, "2.13.2", xmlFilePath);
        }

        public void MigrateToV_2_14(XmlDocument xmlDoc, string xmlFilePath)
        {
            UpdateVersion(xmlDoc, "2.14", xmlFilePath);
        }

        public void MigrateToV_2_14HF1(XmlDocument xmlDoc, string xmlFilePath)
        {
            UpdateVersion(xmlDoc, "2.14.1", xmlFilePath);
        }

        public void MigrateToV_2_14HF2(XmlDocument xmlDoc, string xmlFilePath)
        {
            UpdateVersion(xmlDoc, "2.14.2", xmlFilePath);
        }

        public void MigrateToV_2_14HF3(XmlDocument xmlDoc, string xmlFilePath)
        {
            UpdateVersion(xmlDoc, "2.14.3", xmlFilePath);
        }
    }
}

