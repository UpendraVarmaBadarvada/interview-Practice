﻿using System;
using System.Linq;
using System.Reflection;
using System.Xml;
using MainApp.MigrationFunctions;

namespace MainApp
{
    class Program
    {
        static void Main(string[] args)
        {
            Migration instance = new Migration();
            string xmlFilePath = "migration.xml";
            string moduleName = "CoreModule";

            if (!File.Exists(xmlFilePath))
            {
                Console.WriteLine($"[ERROR] XML file '{xmlFilePath}' not found.");
                return;
            }

            XmlDocument xmlDoc = new XmlDocument();
            xmlDoc.Load(xmlFilePath);

            String startingVersion = GetCurrentVersion(xmlDoc).Replace(".","_");

            // Get list of available migration methods
            var allMethods = typeof(Migration).GetMethods(BindingFlags.Instance | BindingFlags.Public)
                .Where(m => m.Name.StartsWith("MigrateToV_2_"))
                .Select(m => m.Name)
                .OrderBy(name => ExtractNumericPrefix(name))
                .ThenBy(name => name)
                .ToList();

            // Get filtered method list from ProcessMigration
            List<string> selectedMethods = ProcessMigration(allMethods, startingVersion);

            // Execute only the selected methods
            foreach (var methodName in selectedMethods)
            {
                var method = typeof(Migration).GetMethod(methodName);
                if (method != null)
                {
                    Console.WriteLine($"Executing {method.Name}...");

                    ParameterInfo[] parameters = method.GetParameters();
                    object[] argsToPass;

                    if (parameters.Length == 3) // Special case for MigrateToV_2_0
                    {
                        argsToPass = new object[] { xmlDoc, moduleName, xmlFilePath };
                    }
                    else // Default case (all other methods)
                    {
                        argsToPass = new object[] { xmlDoc, xmlFilePath };
                    }

                    method.Invoke(instance, argsToPass);

                    xmlDoc.Load(xmlFilePath); // Reload XML after each migration

                    Console.WriteLine($"Updated XML Version: {GetCurrentVersion(xmlDoc)}");
                }
            }
        }

        static (int major, string suffix) ExtractNumericPrefix(string methodName)
        {
            string[] parts = methodName.Split('_');
            string numericPart = new string(parts.Last().TakeWhile(char.IsDigit).ToArray());
            string suffix = parts.Last().Substring(numericPart.Length);
            return (int.Parse(numericPart), suffix);
        }

        static string GetCurrentVersion(XmlDocument xmlDoc)
        {
            XmlNode childNode = xmlDoc.SelectSingleNode("//Child");
            return childNode?.Attributes["version"]?.Value ?? "Unknown";
        }

        static (string baseVersion, int? hfNumber) ParseVersion(string version)
        {
            string[] parts = version.Replace("MigrateToV_", "").Split("HF");
            string baseVersion = parts[0];
            int? hfNumber = parts.Length > 1 ? int.Parse(parts[1]) : (int?)null;
            return (baseVersion, hfNumber);
        }

        public static List<string> ProcessMigration(List<string> versionList, String startingVersion)
        {
            var parsedVersions = versionList.Select(ParseVersion).ToList();
            int startIndex = parsedVersions.FindIndex(v => v.baseVersion == startingVersion);

            if (startIndex == -1 && startingVersion != "1_0")
            {
                Console.WriteLine("Starting version not found in the list.");
                return new List<string>();
            }

            List<string> nonHfVersions = new List<string>();
            List<(string version, (string baseVersion, int? hfNumber))> hfVersions = new List<(string, (string, int?))>();

            foreach (var version in versionList.Skip(startIndex))
            {
                var parsedVersion = ParseVersion(version);
                if (parsedVersion.hfNumber == null)
                {
                    nonHfVersions.Add(version);
                }
                else
                {
                    hfVersions.Add((version, parsedVersion));
                }
            }

            var lastNonHfVersion = nonHfVersions.Any() ? ParseVersion(nonHfVersions.Last()) : default;
            var relevantHfs = hfVersions.Where(hf => hf.Item2.baseVersion == lastNonHfVersion.baseVersion).ToList();

            int? hfNumber = null;
            if (relevantHfs.Any())
            {
                Console.Write("Enter the HF number you want to execute: ");
                if (int.TryParse(Console.ReadLine(), out int parsedHfNumber))
                {
                    hfNumber = parsedHfNumber;
                }
            }

            List<string> selectedVersions = new List<string>();
            selectedVersions.AddRange(nonHfVersions);

            if (hfNumber.HasValue && relevantHfs.Any())
            {
                var selectedHf = relevantHfs.FirstOrDefault(hf => hf.Item2.hfNumber == hfNumber);
                if (!string.IsNullOrEmpty(selectedHf.version))
                {
                    selectedVersions.Add(selectedHf.version);
                }
            }

            return selectedVersions;
        }
    }
}
